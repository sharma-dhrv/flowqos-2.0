README
=============================================================
FlowQoS: Providing Per-Flow QoS for Broadband Access Networks
=============================================================

User Interface for FlowQoS

User can view and set the bandwidth allocation here.

For test run, you can use built in PHP web server by running
php -S localhost:8000
on your terminal.

